package com.team_E_commerce.commerce_core_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceCoreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
